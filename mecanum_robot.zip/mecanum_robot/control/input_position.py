#!/usr/bin/env python3
import rospy
from std_srvs.srv import*
from huy_package.srv import Position


def destination(x,y,g):
   # rospy.__init__node("CLIEnt")
    rospy.wait_for_service('position')
    try:
        huy = rospy.ServiceProxy('position',Position)
        resp1 = huy(x, y, g)
        return resp1.feedback
    except rospy.ServiceException as e:
        print("Service call failed: %s"%e)


if __name__ == "__main__":
    if len(sys.argv) == 4:
        x = float(sys.argv[1])
        y = float(sys.argv[2])
        g = float(sys.argv[3])
    else:
        print("Sai dau vao")
        sys.exit(1)

    print("{}: ({};{};{}) ".format(destination(x,y,g),x,y,g))

