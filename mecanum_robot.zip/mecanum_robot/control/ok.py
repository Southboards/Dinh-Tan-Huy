#!/usr/bin/env python3
import  rospy, numpy
from math import cos, sin, pi
global Joint_state, co, a, XY
JS = [1.57,0,1.57,0,0,0,0]
XY = [0,0]
co = [0,0,0,0,0,0,0]    
a = [0, 0.1, 0.49, 0.556, 0.267, 0.556, 0.47] 

def aglorithm_thuan(J):
    A0 = [[    cos(J[0])   ,   -sin(J[0])    ,       0      ,          0            ],
          [    sin(J[0])   ,    cos(J[0])    ,       0      ,          0            ],
          [       0        ,        0        ,       1      ,          0            ],
          [       0        ,        0        ,       0      ,          1            ]]

    A1 = [[ cos(J[1]) , -sin(J[1]) ,       0      ,          0            ],
          [ sin(J[1]) ,  cos(J[1]) ,       0      ,          0            ],
          [       0        ,        0        ,       1      ,         a[1]          ],
          [       0        ,        0        ,       0      ,          1            ]]
    
    A2 = [[    cos(J[2])   ,        0        ,  -sin(J[2])  ,          0            ],
          [    sin(J[2])   ,        0        ,   cos(J[2])  ,          0            ],
          [       0        ,       -1        ,       0      ,         a[2]          ],
          [       0        ,        0        ,       0      ,          1            ]]

    A21 =[[    cos(J[2])   ,        0        ,   sin(J[2])  ,          0            ],
          [    sin(J[2])   ,        0        ,  -cos(J[2])  ,          0            ],
          [       0        ,        1        ,       0      ,          0            ],
          [       0        ,        0        ,       0      ,          1            ]]

    A3 = [[    cos(J[3])   ,        0        ,   sin(J[3])  ,          0            ],
          [    sin(J[3])   ,        0        ,  -cos(J[3])  ,          0            ],
          [       0        ,        1        ,       0      ,         a[3]          ],
          [       0        ,        0        ,       0      ,          1            ]]

    A31 =[[    cos(J[3])   ,        0        ,  -sin(J[3])  ,          0            ],
          [    sin(J[3])   ,        0        ,   cos(J[3])  ,          0            ],
          [       0        ,       -1        ,       0      ,          0            ],
          [       0        ,        0        ,       0      ,          1            ]]

    A4 = [[    cos(J[4])   ,    -sin(J[4])   ,       0      ,          0            ],
          [    sin(J[4])   ,     cos(J[4])   ,       0      ,          0            ],
          [       0        ,        0        ,       1      ,         a[4]          ],
          [       0        ,        0        ,       0      ,          1            ]]

    A5 = [[    cos(J[5])   ,        0        ,   sin(J[5])  ,          0            ],
          [    sin(J[5])   ,        0        ,  -cos(J[5])  ,          0            ],
          [       0        ,        1        ,       0      ,         a[5]          ],
          [       0        ,        0        ,       0      ,          1            ]]
      
    A51 =[[    cos(J[5])   ,        0        ,  -sin(J[5])  ,          0            ],
          [    sin(J[5])   ,        0        ,   cos(J[5])  ,          0            ],
          [       0        ,       -1        ,       0      ,          0            ],
          [       0        ,        0        ,       0      ,          1            ]]

    A6 = [[ cos(J[6]) , -sin(J[6]) ,       0      ,          0            ],
          [ sin(J[6]) ,  cos(J[6]) ,       0      ,          0            ],
          [       0        ,        0        ,       1      ,         a[6]          ],
          [       0        ,        0        ,       0      ,          1            ]]


    A7 = [[    0     ,      0     ,       0     ,       XY[1]      ],
          [    0     ,      0     ,       0     ,       XY[0]      ],
          [    0     ,      0     ,       0     ,         0        ],
          [    0     ,      0     ,       0     ,         0        ]]

    A0 = numpy.array(A0)
    A1 = numpy.array(A1)
    A2 = numpy.array(A2)  
    A21 = numpy.array(A21)   
    A3 = numpy.array(A3)
    A31 = numpy.array(A31)
    A4 = numpy.array(A4)
    A5 = numpy.array(A5)
    A51 = numpy.array(A51)
    A6 = numpy.array(A6)
    A7 = numpy.array(A7)
    T = A0.dot(A1).dot(A2).dot(A21).dot(A3).dot(A31).dot(A4).dot(A5).dot(A51).dot(A6) 
    
    print("\n{} \n----------------".format(T))

aglorithm_thuan(JS)
