#!/usr/bin/env python3
import math, rospy, numpy
from control_msgs.msg import JointControllerState
from std_msgs.msg import Float64
def pub(J):
    rospy.init_node('control_7dof', anonymous=True)
    pub1 = rospy.Publisher('/elfin/joint1_position_controller/command', Float64, queue_size=10)
    pub2 = rospy.Publisher('/elfin/joint2_position_controller/command', Float64, queue_size=10)
    pub3 = rospy.Publisher('/elfin/joint3_position_controller/command', Float64, queue_size=10)
    pub4 = rospy.Publisher('/elfin/joint4_position_controller/command', Float64, queue_size=10)
    pub5 = rospy.Publisher('/elfin/joint5_position_controller/command', Float64, queue_size=10)
    pub6 = rospy.Publisher('/elfin/joint6_position_controller/command', Float64, queue_size=10)
    while 1:
        pub1.publish(J[0])
        pub2.publish(J[1])      
        pub3.publish(J[2])      
        pub4.publish(J[3])
        pub5.publish(J[4])
        pub6.publish(J[5])
    rospy.spin()
if __name__ == "__main__":
    pub([0,1.57,0,0,0,0])