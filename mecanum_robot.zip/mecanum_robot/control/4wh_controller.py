#!/usr/bin/env python3
import math, rospy, numpy

from std_msgs.msg import Float64
from gazebo_msgs.msg import ModelStates
from sensor_msgs.msg import JointState
from geometry_msgs.msg import Vector3
from huy_package.srv import Position,PositionResponse



def setup(): 
    global co1, co2
    co1 = co2 = False
    rospy.init_node('controller_4wh', anonymous=True)
    rospy.Subscriber('mecanum_robot/joint_states',JointState, trans_joint_state_data)
    rospy.Service('position',Position, receive_input_position)
   # print("Ready to run: ")
    rospy.Subscriber('gazebo/model_states',ModelStates, change_feedback_data)
    
    rospy.spin()

def trans_joint_state_data(P):
    a = 15 #chieu dai don vi cm
    b = 15  #chieu rong
    c = 100/(a+b) 
    d = math.sqrt(a**2+b**2)    
    r = 5 # ban kinh banh xe mecanum la 50mm
    global real_velocity, co2, real_position
    real_velocity = [0,0,0]                 
    real_position = [0,0,0]
    rv = P.velocity
    real_velocity[0] = rv[2]
    real_velocity[1] = rv[1]
    real_velocity[2] = rv[0]
    rp = P.position          #b[3] la banh 1 ; b[2] la banh 2 ; b[1] la banh 4  ; b[0] la banh 3
    real_position[2] = (-rp[3] + rp[2] - rp[0] + rp[1])/d
    
    real_position[2] = real_position[2]%(numpy.pi*2)
    
    co2 = True

def receive_input_position(data):
    global X_end, Y_end, G_end,co1
    
    X_end = data.x
    Y_end = data.y
    G_end = data.g
    
    co1 = True 
    return PositionResponse("Robot dang di chuyen ve diem")

def change_feedback_data(data):
    global X_end, Y_end, G_end, co1, co2
    global real_position,real_orientation,real_ang_velocity

    P = str(data.pose[1])
    P = P.split(" ")
    B = [P[4].split("\n"), P[7].split("\n"), P[10].split("\n")]
    #real_position = [B[0][0],B[1][0],B[2][0]]                       #xyz
    C = [P[14].split("\n"), P[17].split("\n"), P[20].split("\n")]
    real_orientation = [C[0][0],C[1][0],C[2][0]]
    E = str(data.twist[1])
    E = E.split(" ")
    M = [E[14].split("\n"), E[17].split("\n"), E[20].split("\n")]
    real_ang_velocity=[M[0][0],M[1][0],M[2][0]]     #van toc goc
    
    real_position[0] = B[0][0]               #xyg
    real_position[1] = B[1][0]               

    if co1 and co2:
        aglorithm_position()
    else:
        publish_V(0,0,0,0,real_position)

def aglorithm_position(): #chua lam control orientation va control velocity
    global X_end, Y_end, G_end
    global real_position,real_orientation,real_velocity,real_ang_velocity
    real_position[0]=float(real_position[0])
    real_position[1]=float(real_position[1])
    real_position[2] = float(real_position[2])
    e=[0,0]
    e[0]=float(X_end)-real_position[0]
    e[1]=float(Y_end)-real_position[1]
    g=float(G_end)-real_position[2]
    g = g%(numpy.pi*2)
    #print("\n",real_position[2])
    #print("\n g = \n", g)
    #print("X: {}\nY: {}\nG: {}".format(real_position[0],real_position[1],real_position[2]))
    if abs(e[0])<0.02 and abs(e[1])<0.02 and (abs(g)<0.01 or abs(g)>6.27):
        V1=V2=V3=V4=0

    else:
        if abs(g)<0.01 or abs(g)>6.27:
            
            alpha = math.pi/4
            R = [[math.cos(real_position[2]), -math.sin(real_position[2])],
                [math.sin(real_position[2]), math.cos(real_position[2])]]
            H = [[-math.cos(alpha), math.cos(alpha)],
                [math.sin(alpha), math.sin(alpha)]]
            H=numpy.array(H)
            R=numpy.array(R)
            H = R.dot(H)
            H = numpy.linalg.inv(H)
            e = numpy.array(e)
            V = H.dot(e)
            t = max(abs(V[0]),abs(V[1]))
            V = (V/t)*10
            V1=V3=V[0]
            V2=V4=V[1]
            
        elif abs(g)>numpy.pi:
            V1=V4=-2
            V2=V3=-V1
        elif abs(g)<=numpy.pi:
            V1=V4=2
            V2=V3=-V1
            
    publish_V(V1,V2,V3,V4,real_position)    


def publish_V(V1,V2,V3,V4,real_pos):
    V1_pub = rospy.Publisher('mecanum_robot/fr_joint_velocity_controller/command',Float64, queue_size=10)
    V2_pub = rospy.Publisher('mecanum_robot/fl_joint_velocity_controller/command',Float64, queue_size=10)
    V3_pub = rospy.Publisher('mecanum_robot/br_joint_velocity_controller/command',Float64, queue_size=10)
    V4_pub = rospy.Publisher('mecanum_robot/bl_joint_velocity_controller/command',Float64, queue_size=10)
    RP = rospy.Publisher('mecanum_robot/feed_back_joint0', Vector3, queue_size=10)
    V1=-float(V1)       #banh 1  va banh 3 nguoc chieu dong co
    V2=-float(V2)
    V3=float(V3)
    V4=float(V4)
    a = Vector3()
    a.x = float(real_pos[0])
    a.y = float(real_pos[1])
    a.z = float(real_pos[2])
    V1_pub.publish(V1)
    V2_pub.publish(V2)
    V3_pub.publish(V3)
    V4_pub.publish(V4)
    
    RP.publish(a)

   # print("V1={}\nV2={}\nV3={}\nV4={}\n---".format(V1,V2,V3,V4))
if __name__ == '__main__':
    global real_velocity, co2, real_position, co1
    real_position=[0,0,0]
    setup()
        
        
         
        
        


        
    
    
        
        
        
        

