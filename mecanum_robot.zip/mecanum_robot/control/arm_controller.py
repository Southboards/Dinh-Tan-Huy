#!/usr/bin/env python3
import  rospy, numpy
from control_msgs.msg import JointControllerState
from std_msgs.msg import Float64
from geometry_msgs.msg import Vector3
from math import cos, sin
global Joint_state, co, a, XY
JS = [0,0,0,0,0,0,0]
XY = [0,0]
co = [0,0,0,0,0,0,0]    
a = [0, 0.1, 0.49, 0.675, 0.267, 0.556, 0.47]      # khoang cach cac goc toa do
def setup():
    global JS, co
    rospy.init_node('control_arm_6dot', anonymous=True)
    rospy.Subscriber('mecanum_robot/feed_back_joint0', Vector3, trans_joint0_state_data)
    rospy.Subscriber('/elfin/joint1_position_controller/state',JointControllerState, trans_joint1_state_data)
    rospy.Subscriber('/elfin/joint2_position_controller/state',JointControllerState, trans_joint2_state_data)
    rospy.Subscriber('/elfin/joint3_position_controller/state',JointControllerState, trans_joint3_state_data)
    rospy.Subscriber('/elfin/joint4_position_controller/state',JointControllerState, trans_joint4_state_data)
    rospy.Subscriber('/elfin/joint5_position_controller/state',JointControllerState, trans_joint5_state_data)
    rospy.Subscriber('/elfin/joint6_position_controller/state',JointControllerState, trans_joint6_state_data)
    
    rospy.spin()

def trans_joint0_state_data(D):
    JS[0] = D.z
    XY[0] = D.x
    XY[1] = D.y
    co[0]=1
def trans_joint1_state_data(J_data):
    JS[1] = J_data.process_value
    co[1]=1
def trans_joint2_state_data(J_data):
    JS[2] = J_data.process_value 
    co[2]=1
def trans_joint3_state_data(J_data):
    JS[3] = J_data.process_value 
    co[3]=1  
def trans_joint4_state_data(J_data):
    JS[4] = J_data.process_value 
    co[4]=1 
def trans_joint5_state_data(J_data):
    JS[5] = J_data.process_value 
    co[5]=1
def trans_joint6_state_data(J_data): 
    JS[6] = J_data.process_value 
    co[6]=1
    if co == [1,1,1,1,1,1,1]:
        #print(JS)
        aglorithm_thuan(JS)
def aglorithm_thuan(J):
    A0 = [[    cos(J[0])   ,   -sin(J[0])    ,       0      ,        0        ],
          [    sin(J[0])   ,    cos(J[0])    ,       0      ,        0        ],
          [       0        ,        0        ,       1      ,        0        ],
          [       0        ,        0        ,       0      ,        1        ]]

    A1 = [[    cos(J[1])   ,   -sin(J[1])    ,       0      ,        0        ],
          [    sin(J[1])   ,    cos(J[1])    ,       0      ,        0        ],
          [       0        ,        0        ,       1      ,       a[1]      ],
          [       0        ,        0        ,       0      ,        1        ]]
    
    A2 = [[    cos(J[2])   ,        0        ,  -sin(J[2])  ,        0        ],
          [    sin(J[2])   ,        0        ,   cos(J[2])  ,        0        ],
          [       0        ,       -1        ,       0      ,       a[2]      ],
          [       0        ,        0        ,       0      ,        1        ]]

    A21 =[[    cos(J[2])   ,        0        ,   sin(J[2])  ,        0        ],
          [    sin(J[2])   ,        0        ,  -cos(J[2])  ,        0        ],
          [       0        ,        1        ,       0      ,        0        ],
          [       0        ,        0        ,       0      ,        1        ]]

    A3 = [[    cos(J[3])   ,        0        ,   sin(J[3])  ,        0        ],
          [    sin(J[3])   ,        0        ,  -cos(J[3])  ,        0        ],
          [       0        ,        1        ,       0      ,       a[3]      ],
          [       0        ,        0        ,       0      ,        1        ]]

    A31 =[[    cos(J[3])   ,        0        ,  -sin(J[3])  ,        0        ],
          [    sin(J[3])   ,        0        ,   cos(J[3])  ,        0        ],
          [       0        ,       -1        ,       0      ,        0        ],
          [       0        ,        0        ,       0      ,        1        ]]

    A4 = [[    cos(J[4])   ,    -sin(J[4])   ,       0      ,        0        ],
          [    sin(J[4])   ,     cos(J[4])   ,       0      ,        0        ],
          [       0        ,        0        ,       1      ,       a[4]      ],
          [       0        ,        0        ,       0      ,        1        ]]

    A5 = [[    cos(J[5])   ,        0        ,   sin(J[5])  ,        0        ],
          [    sin(J[5])   ,        0        ,  -cos(J[5])  ,        0        ],
          [       0        ,        1        ,       0      ,       a[5]      ],
          [       0        ,        0        ,       0      ,        1        ]]
      
    A51 =[[    cos(J[5])   ,        0        ,  -sin(J[5])  ,        0        ],
          [    sin(J[5])   ,        0        ,   cos(J[5])  ,        0        ],
          [       0        ,       -1        ,       0      ,        0        ],
          [       0        ,        0        ,       0      ,        1        ]]

    A6 = [[    cos(J[6])   ,    -sin(J[6])   ,       0      ,        0        ],
          [    sin(J[6])   ,     cos(J[6])   ,       0      ,        0        ],
          [       0        ,        0        ,       1      ,       a[6]      ],
          [       0        ,        0        ,       0      ,        1        ]]


    A7 = [[    0     ,      0     ,       0     ,       XY[0]      ],
          [    0     ,      0     ,       0     ,       XY[1]      ],
          [    0     ,      0     ,       0     ,         0        ],
          [    0     ,      0     ,       0     ,         0        ]]

    A0 = numpy.array(A0)
    A1 = numpy.array(A1)
    A2 = numpy.array(A2)  
    A21 = numpy.array(A21)   
    A3 = numpy.array(A3)
    A31 = numpy.array(A31)
    A4 = numpy.array(A4)
    A5 = numpy.array(A5)
    A51 = numpy.array(A51)
    A6 = numpy.array(A6)
    A7 = numpy.array(A7)
    T = A0.dot(A1).dot(A2).dot(A21).dot(A3).dot(A31).dot(A4).dot(A5).dot(A51).dot(A6) + A7
    
    print("\n{} \n----------------".format(T))

def pub(J):
    
    pub1 = rospy.Publisher('/elfin/joint1_position_controller/command', Float64, queue_size=10)
    pub2 = rospy.Publisher('/elfin/joint2_position_controller/command', Float64, queue_size=10)
    pub3 = rospy.Publisher('/elfin/joint3_position_controller/command', Float64, queue_size=10)
    pub4 = rospy.Publisher('/elfin/joint4_position_controller/command', Float64, queue_size=10)
    pub5 = rospy.Publisher('/elfin/joint5_position_controller/command', Float64, queue_size=10)
    pub6 = rospy.Publisher('/elfin/joint6_position_controller/command', Float64, queue_size=10)
    
    pub1.publish(J[1])
    pub2.publish(J[2])      
    pub3.publish(J[3])      
    pub4.publish(J[4])
    pub5.publish(J[5])
    pub6.publish(J[6])
    print(JS)

if __name__ == "__main__":
    
    setup()